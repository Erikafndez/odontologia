﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class menupaciente : Form
    {
        public menupaciente()
        {
            InitializeComponent();
        }

        private void bttAgendadecita_Click(object sender, EventArgs e)
        {
            agendacitaspaciente form = new agendacitaspaciente();
            form.Show();
            this.Hide();
        }

        private void bttRequisitodepaciente_Click(object sender, EventArgs e)
        {
            datosbasicospaciente form = new datosbasicospaciente();
            form.Show();
            this.Hide();
        }

        private void bttRegresar_Click(object sender, EventArgs e)
        {
            Form1 x = new Form1();
            x.Show();
            Hide();
        }
    }
}
