﻿namespace WindowsFormsApp2
{
    partial class menupaciente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttAgendadecita = new System.Windows.Forms.Button();
            this.bttRequisitodepaciente = new System.Windows.Forms.Button();
            this.bttRegresar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bttAgendadecita
            // 
            this.bttAgendadecita.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.bttAgendadecita.Location = new System.Drawing.Point(97, 36);
            this.bttAgendadecita.Name = "bttAgendadecita";
            this.bttAgendadecita.Size = new System.Drawing.Size(165, 89);
            this.bttAgendadecita.TabIndex = 77;
            this.bttAgendadecita.Text = "Agenda de cita ";
            this.bttAgendadecita.UseVisualStyleBackColor = false;
            this.bttAgendadecita.Click += new System.EventHandler(this.bttAgendadecita_Click);
            // 
            // bttRequisitodepaciente
            // 
            this.bttRequisitodepaciente.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.bttRequisitodepaciente.Location = new System.Drawing.Point(97, 283);
            this.bttRequisitodepaciente.Name = "bttRequisitodepaciente";
            this.bttRequisitodepaciente.Size = new System.Drawing.Size(165, 84);
            this.bttRequisitodepaciente.TabIndex = 76;
            this.bttRequisitodepaciente.Text = "Informacion del paciente";
            this.bttRequisitodepaciente.UseVisualStyleBackColor = false;
            this.bttRequisitodepaciente.Click += new System.EventHandler(this.bttRequisitodepaciente_Click);
            // 
            // bttRegresar
            // 
            this.bttRegresar.BackColor = System.Drawing.Color.Silver;
            this.bttRegresar.Location = new System.Drawing.Point(318, 162);
            this.bttRegresar.Name = "bttRegresar";
            this.bttRegresar.Size = new System.Drawing.Size(173, 84);
            this.bttRegresar.TabIndex = 80;
            this.bttRegresar.Text = "Regresar";
            this.bttRegresar.UseVisualStyleBackColor = false;
            this.bttRegresar.Click += new System.EventHandler(this.bttRegresar_Click);
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp2.Properties.Resources.depositphotos_113775894_stock_illustration_seamless_teeth_dentistry_background;
            this.ClientSize = new System.Drawing.Size(536, 450);
            this.Controls.Add(this.bttRegresar);
            this.Controls.Add(this.bttAgendadecita);
            this.Controls.Add(this.bttRequisitodepaciente);
            this.Name = "Form7";
            this.Text = "Menu paciente";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bttAgendadecita;
        private System.Windows.Forms.Button bttRequisitodepaciente;
        private System.Windows.Forms.Button bttRegresar;
    }
}