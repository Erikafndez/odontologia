﻿namespace WindowsFormsApp2
{
    partial class datosbasicospaciente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.errorMensaje = new System.Windows.Forms.ErrorProvider(this.components);
            this.gpbdatosbasicos = new System.Windows.Forms.GroupBox();
            this.bttguardar = new System.Windows.Forms.Button();
            this.bttregresar = new System.Windows.Forms.Button();
            this.dtpfechadenacimiento = new System.Windows.Forms.DateTimePicker();
            this.cbxtipodeidentificacion = new System.Windows.Forms.ComboBox();
            this.cbxgenero = new System.Windows.Forms.ComboBox();
            this.cbxestadocivil = new System.Windows.Forms.ComboBox();
            this.cbxnivelescolaridad = new System.Windows.Forms.ComboBox();
            this.cbxregimen = new System.Windows.Forms.ComboBox();
            this.txtdireccion = new System.Windows.Forms.TextBox();
            this.lbldireccion = new System.Windows.Forms.Label();
            this.txteps = new System.Windows.Forms.TextBox();
            this.lbleps = new System.Windows.Forms.Label();
            this.txtedad = new System.Windows.Forms.TextBox();
            this.lbledad = new System.Windows.Forms.Label();
            this.lblfechanacimiento = new System.Windows.Forms.Label();
            this.txtantecedentes = new System.Windows.Forms.TextBox();
            this.lblantecedentes = new System.Windows.Forms.Label();
            this.txttratamiento = new System.Windows.Forms.TextBox();
            this.lbltratamiento = new System.Windows.Forms.Label();
            this.txtcontactoemergencia = new System.Windows.Forms.TextBox();
            this.lblcontactoemergencia = new System.Windows.Forms.Label();
            this.lblregimen = new System.Windows.Forms.Label();
            this.txtcorreoelectronico = new System.Windows.Forms.TextBox();
            this.lblcorreoelectronico = new System.Windows.Forms.Label();
            this.lblnivelescolaridad = new System.Windows.Forms.Label();
            this.txtocupacion = new System.Windows.Forms.TextBox();
            this.lblocupacion = new System.Windows.Forms.Label();
            this.txttelefono = new System.Windows.Forms.TextBox();
            this.lbltelefono = new System.Windows.Forms.Label();
            this.txtbarrio = new System.Windows.Forms.TextBox();
            this.lblbarrio = new System.Windows.Forms.Label();
            this.lblestadocivil = new System.Windows.Forms.Label();
            this.lblgenero = new System.Windows.Forms.Label();
            this.txtnumeroidentificacion = new System.Windows.Forms.TextBox();
            this.lblnumeroidentificacion = new System.Windows.Forms.Label();
            this.lbltipoidentificacion = new System.Windows.Forms.Label();
            this.txtnombrescompletos = new System.Windows.Forms.TextBox();
            this.lblnombrescompletos = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.errorMensaje)).BeginInit();
            this.gpbdatosbasicos.SuspendLayout();
            this.SuspendLayout();
            // 
            // errorMensaje
            // 
            this.errorMensaje.ContainerControl = this;
            // 
            // gpbdatosbasicos
            // 
            this.gpbdatosbasicos.BackgroundImage = global::WindowsFormsApp2.Properties.Resources.sistema_sano_del_icono_del_diente_crema_dental_del_cepillo_de_dientes_personaje_de_dibujos_animados_971017681;
            this.gpbdatosbasicos.Controls.Add(this.bttguardar);
            this.gpbdatosbasicos.Controls.Add(this.bttregresar);
            this.gpbdatosbasicos.Controls.Add(this.dtpfechadenacimiento);
            this.gpbdatosbasicos.Controls.Add(this.cbxtipodeidentificacion);
            this.gpbdatosbasicos.Controls.Add(this.cbxgenero);
            this.gpbdatosbasicos.Controls.Add(this.cbxestadocivil);
            this.gpbdatosbasicos.Controls.Add(this.cbxnivelescolaridad);
            this.gpbdatosbasicos.Controls.Add(this.cbxregimen);
            this.gpbdatosbasicos.Controls.Add(this.txtdireccion);
            this.gpbdatosbasicos.Controls.Add(this.lbldireccion);
            this.gpbdatosbasicos.Controls.Add(this.txteps);
            this.gpbdatosbasicos.Controls.Add(this.lbleps);
            this.gpbdatosbasicos.Controls.Add(this.txtedad);
            this.gpbdatosbasicos.Controls.Add(this.lbledad);
            this.gpbdatosbasicos.Controls.Add(this.lblfechanacimiento);
            this.gpbdatosbasicos.Controls.Add(this.txtantecedentes);
            this.gpbdatosbasicos.Controls.Add(this.lblantecedentes);
            this.gpbdatosbasicos.Controls.Add(this.txttratamiento);
            this.gpbdatosbasicos.Controls.Add(this.lbltratamiento);
            this.gpbdatosbasicos.Controls.Add(this.txtcontactoemergencia);
            this.gpbdatosbasicos.Controls.Add(this.lblcontactoemergencia);
            this.gpbdatosbasicos.Controls.Add(this.lblregimen);
            this.gpbdatosbasicos.Controls.Add(this.txtcorreoelectronico);
            this.gpbdatosbasicos.Controls.Add(this.lblcorreoelectronico);
            this.gpbdatosbasicos.Controls.Add(this.lblnivelescolaridad);
            this.gpbdatosbasicos.Controls.Add(this.txtocupacion);
            this.gpbdatosbasicos.Controls.Add(this.lblocupacion);
            this.gpbdatosbasicos.Controls.Add(this.txttelefono);
            this.gpbdatosbasicos.Controls.Add(this.lbltelefono);
            this.gpbdatosbasicos.Controls.Add(this.txtbarrio);
            this.gpbdatosbasicos.Controls.Add(this.lblbarrio);
            this.gpbdatosbasicos.Controls.Add(this.lblestadocivil);
            this.gpbdatosbasicos.Controls.Add(this.lblgenero);
            this.gpbdatosbasicos.Controls.Add(this.txtnumeroidentificacion);
            this.gpbdatosbasicos.Controls.Add(this.lblnumeroidentificacion);
            this.gpbdatosbasicos.Controls.Add(this.lbltipoidentificacion);
            this.gpbdatosbasicos.Controls.Add(this.txtnombrescompletos);
            this.gpbdatosbasicos.Controls.Add(this.lblnombrescompletos);
            this.gpbdatosbasicos.Location = new System.Drawing.Point(2, 12);
            this.gpbdatosbasicos.Name = "gpbdatosbasicos";
            this.gpbdatosbasicos.Size = new System.Drawing.Size(876, 418);
            this.gpbdatosbasicos.TabIndex = 1;
            this.gpbdatosbasicos.TabStop = false;
            this.gpbdatosbasicos.Text = "Datos Basicos";
            // 
            // bttguardar
            // 
            this.bttguardar.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.bttguardar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttguardar.Location = new System.Drawing.Point(744, 222);
            this.bttguardar.Name = "bttguardar";
            this.bttguardar.Size = new System.Drawing.Size(106, 74);
            this.bttguardar.TabIndex = 38;
            this.bttguardar.Text = "Guardar";
            this.bttguardar.UseVisualStyleBackColor = false;
            this.bttguardar.Click += new System.EventHandler(this.bttguardar_Click);
            // 
            // bttregresar
            // 
            this.bttregresar.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.bttregresar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttregresar.Location = new System.Drawing.Point(615, 222);
            this.bttregresar.Name = "bttregresar";
            this.bttregresar.Size = new System.Drawing.Size(103, 74);
            this.bttregresar.TabIndex = 37;
            this.bttregresar.Text = "Regresar";
            this.bttregresar.UseVisualStyleBackColor = false;
            this.bttregresar.Click += new System.EventHandler(this.bttregresar_Click);
            // 
            // dtpfechadenacimiento
            // 
            this.dtpfechadenacimiento.Location = new System.Drawing.Point(425, 329);
            this.dtpfechadenacimiento.Name = "dtpfechadenacimiento";
            this.dtpfechadenacimiento.Size = new System.Drawing.Size(205, 20);
            this.dtpfechadenacimiento.TabIndex = 36;
            // 
            // cbxtipodeidentificacion
            // 
            this.cbxtipodeidentificacion.FormattingEnabled = true;
            this.cbxtipodeidentificacion.Items.AddRange(new object[] {
            "Cédula Cuidadania",
            "Tarjeta de identificación",
            "Cédula Extranjera"});
            this.cbxtipodeidentificacion.Location = new System.Drawing.Point(167, 84);
            this.cbxtipodeidentificacion.Name = "cbxtipodeidentificacion";
            this.cbxtipodeidentificacion.Size = new System.Drawing.Size(121, 21);
            this.cbxtipodeidentificacion.TabIndex = 2;
            // 
            // cbxgenero
            // 
            this.cbxgenero.FormattingEnabled = true;
            this.cbxgenero.Items.AddRange(new object[] {
            "Masculino",
            "Femenino"});
            this.cbxgenero.Location = new System.Drawing.Point(140, 180);
            this.cbxgenero.Name = "cbxgenero";
            this.cbxgenero.Size = new System.Drawing.Size(121, 21);
            this.cbxgenero.TabIndex = 3;
            // 
            // cbxestadocivil
            // 
            this.cbxestadocivil.FormattingEnabled = true;
            this.cbxestadocivil.Items.AddRange(new object[] {
            "Casado",
            "Soltero",
            "Vuido",
            "Divorsiado",
            "Union libre"});
            this.cbxestadocivil.Location = new System.Drawing.Point(140, 309);
            this.cbxestadocivil.Name = "cbxestadocivil";
            this.cbxestadocivil.Size = new System.Drawing.Size(121, 21);
            this.cbxestadocivil.TabIndex = 4;
            // 
            // cbxnivelescolaridad
            // 
            this.cbxnivelescolaridad.FormattingEnabled = true;
            this.cbxnivelescolaridad.Items.AddRange(new object[] {
            "Basica primaria",
            "basica secundaria",
            "tecnica",
            "tegnologia",
            "universitario",
            "ninguno"});
            this.cbxnivelescolaridad.Location = new System.Drawing.Point(423, 187);
            this.cbxnivelescolaridad.Name = "cbxnivelescolaridad";
            this.cbxnivelescolaridad.Size = new System.Drawing.Size(121, 21);
            this.cbxnivelescolaridad.TabIndex = 5;
            // 
            // cbxregimen
            // 
            this.cbxregimen.FormattingEnabled = true;
            this.cbxregimen.Items.AddRange(new object[] {
            "Contributivo",
            "Subsidiado",
            "Especial"});
            this.cbxregimen.Location = new System.Drawing.Point(750, 40);
            this.cbxregimen.Name = "cbxregimen";
            this.cbxregimen.Size = new System.Drawing.Size(121, 21);
            this.cbxregimen.TabIndex = 6;
            // 
            // txtdireccion
            // 
            this.txtdireccion.Location = new System.Drawing.Point(170, 361);
            this.txtdireccion.Name = "txtdireccion";
            this.txtdireccion.Size = new System.Drawing.Size(100, 20);
            this.txtdireccion.TabIndex = 35;
            // 
            // lbldireccion
            // 
            this.lbldireccion.AutoSize = true;
            this.lbldireccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldireccion.Location = new System.Drawing.Point(3, 361);
            this.lbldireccion.Name = "lbldireccion";
            this.lbldireccion.Size = new System.Drawing.Size(144, 15);
            this.lbldireccion.TabIndex = 34;
            this.lbldireccion.Text = "Dirección Residencia";
            // 
            // txteps
            // 
            this.txteps.Location = new System.Drawing.Point(140, 223);
            this.txteps.Name = "txteps";
            this.txteps.Size = new System.Drawing.Size(100, 20);
            this.txteps.TabIndex = 33;
            // 
            // lbleps
            // 
            this.lbleps.AutoSize = true;
            this.lbleps.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbleps.Location = new System.Drawing.Point(22, 226);
            this.lbleps.Name = "lbleps";
            this.lbleps.Size = new System.Drawing.Size(34, 15);
            this.lbleps.TabIndex = 32;
            this.lbleps.Text = "EPS";
            // 
            // txtedad
            // 
            this.txtedad.Location = new System.Drawing.Point(140, 263);
            this.txtedad.Name = "txtedad";
            this.txtedad.Size = new System.Drawing.Size(100, 20);
            this.txtedad.TabIndex = 31;
            // 
            // lbledad
            // 
            this.lbledad.AutoSize = true;
            this.lbledad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbledad.Location = new System.Drawing.Point(18, 263);
            this.lbledad.Name = "lbledad";
            this.lbledad.Size = new System.Drawing.Size(40, 15);
            this.lbledad.TabIndex = 30;
            this.lbledad.Text = "Edad";
            // 
            // lblfechanacimiento
            // 
            this.lblfechanacimiento.AutoSize = true;
            this.lblfechanacimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfechanacimiento.Location = new System.Drawing.Point(296, 329);
            this.lblfechanacimiento.Name = "lblfechanacimiento";
            this.lblfechanacimiento.Size = new System.Drawing.Size(123, 15);
            this.lblfechanacimiento.TabIndex = 28;
            this.lblfechanacimiento.Text = "Fecha Nacimiento";
            // 
            // txtantecedentes
            // 
            this.txtantecedentes.Location = new System.Drawing.Point(443, 237);
            this.txtantecedentes.Name = "txtantecedentes";
            this.txtantecedentes.Size = new System.Drawing.Size(100, 20);
            this.txtantecedentes.TabIndex = 27;
            // 
            // lblantecedentes
            // 
            this.lblantecedentes.AutoSize = true;
            this.lblantecedentes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblantecedentes.Location = new System.Drawing.Point(286, 238);
            this.lblantecedentes.Name = "lblantecedentes";
            this.lblantecedentes.Size = new System.Drawing.Size(151, 15);
            this.lblantecedentes.TabIndex = 26;
            this.lblantecedentes.Text = "Antecedentes Médicos";
            // 
            // txttratamiento
            // 
            this.txttratamiento.Location = new System.Drawing.Point(750, 169);
            this.txttratamiento.Name = "txttratamiento";
            this.txttratamiento.Size = new System.Drawing.Size(100, 20);
            this.txttratamiento.TabIndex = 25;
            // 
            // lbltratamiento
            // 
            this.lbltratamiento.AutoSize = true;
            this.lbltratamiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltratamiento.Location = new System.Drawing.Point(542, 160);
            this.lbltratamiento.Name = "lbltratamiento";
            this.lbltratamiento.Size = new System.Drawing.Size(149, 15);
            this.lbltratamiento.TabIndex = 24;
            this.lbltratamiento.Text = "Tratamiento a realizar";
            // 
            // txtcontactoemergencia
            // 
            this.txtcontactoemergencia.Location = new System.Drawing.Point(748, 113);
            this.txtcontactoemergencia.Name = "txtcontactoemergencia";
            this.txtcontactoemergencia.Size = new System.Drawing.Size(100, 20);
            this.txtcontactoemergencia.TabIndex = 23;
            // 
            // lblcontactoemergencia
            // 
            this.lblcontactoemergencia.AutoSize = true;
            this.lblcontactoemergencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcontactoemergencia.Location = new System.Drawing.Point(524, 117);
            this.lblcontactoemergencia.Name = "lblcontactoemergencia";
            this.lblcontactoemergencia.Size = new System.Drawing.Size(218, 15);
            this.lblcontactoemergencia.TabIndex = 22;
            this.lblcontactoemergencia.Text = "Contacto en caso de Emergencia";
            // 
            // lblregimen
            // 
            this.lblregimen.AutoSize = true;
            this.lblregimen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblregimen.Location = new System.Drawing.Point(626, 44);
            this.lblregimen.Name = "lblregimen";
            this.lblregimen.Size = new System.Drawing.Size(65, 15);
            this.lblregimen.TabIndex = 20;
            this.lblregimen.Text = "Régimen";
            // 
            // txtcorreoelectronico
            // 
            this.txtcorreoelectronico.Location = new System.Drawing.Point(423, 281);
            this.txtcorreoelectronico.Name = "txtcorreoelectronico";
            this.txtcorreoelectronico.Size = new System.Drawing.Size(100, 20);
            this.txtcorreoelectronico.TabIndex = 19;
            // 
            // lblcorreoelectronico
            // 
            this.lblcorreoelectronico.AutoSize = true;
            this.lblcorreoelectronico.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcorreoelectronico.Location = new System.Drawing.Point(295, 281);
            this.lblcorreoelectronico.Name = "lblcorreoelectronico";
            this.lblcorreoelectronico.Size = new System.Drawing.Size(126, 15);
            this.lblcorreoelectronico.TabIndex = 18;
            this.lblcorreoelectronico.Text = "Correo Electronico";
            // 
            // lblnivelescolaridad
            // 
            this.lblnivelescolaridad.AutoSize = true;
            this.lblnivelescolaridad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnivelescolaridad.Location = new System.Drawing.Point(286, 188);
            this.lblnivelescolaridad.Name = "lblnivelescolaridad";
            this.lblnivelescolaridad.Size = new System.Drawing.Size(118, 15);
            this.lblnivelescolaridad.TabIndex = 16;
            this.lblnivelescolaridad.Text = "Nivel escolaridad";
            // 
            // txtocupacion
            // 
            this.txtocupacion.Location = new System.Drawing.Point(391, 117);
            this.txtocupacion.Name = "txtocupacion";
            this.txtocupacion.Size = new System.Drawing.Size(100, 20);
            this.txtocupacion.TabIndex = 15;
            // 
            // lblocupacion
            // 
            this.lblocupacion.AutoSize = true;
            this.lblocupacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblocupacion.Location = new System.Drawing.Point(286, 124);
            this.lblocupacion.Name = "lblocupacion";
            this.lblocupacion.Size = new System.Drawing.Size(75, 15);
            this.lblocupacion.TabIndex = 14;
            this.lblocupacion.Text = "Ocupación";
            // 
            // txttelefono
            // 
            this.txttelefono.Location = new System.Drawing.Point(423, 80);
            this.txttelefono.Name = "txttelefono";
            this.txttelefono.Size = new System.Drawing.Size(100, 20);
            this.txttelefono.TabIndex = 13;
            // 
            // lbltelefono
            // 
            this.lbltelefono.AutoSize = true;
            this.lbltelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltelefono.Location = new System.Drawing.Point(294, 80);
            this.lbltelefono.Name = "lbltelefono";
            this.lbltelefono.Size = new System.Drawing.Size(123, 15);
            this.lbltelefono.TabIndex = 12;
            this.lbltelefono.Text = "Teléfono Contacto";
            // 
            // txtbarrio
            // 
            this.txtbarrio.Location = new System.Drawing.Point(423, 39);
            this.txtbarrio.Name = "txtbarrio";
            this.txtbarrio.Size = new System.Drawing.Size(100, 20);
            this.txtbarrio.TabIndex = 11;
            // 
            // lblbarrio
            // 
            this.lblbarrio.AutoSize = true;
            this.lblbarrio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbarrio.Location = new System.Drawing.Point(278, 40);
            this.lblbarrio.Name = "lblbarrio";
            this.lblbarrio.Size = new System.Drawing.Size(122, 15);
            this.lblbarrio.TabIndex = 10;
            this.lblbarrio.Text = "Barrio Residencia";
            // 
            // lblestadocivil
            // 
            this.lblestadocivil.AutoSize = true;
            this.lblestadocivil.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblestadocivil.Location = new System.Drawing.Point(18, 312);
            this.lblestadocivil.Name = "lblestadocivil";
            this.lblestadocivil.Size = new System.Drawing.Size(82, 15);
            this.lblestadocivil.TabIndex = 8;
            this.lblestadocivil.Text = "Estado Civil";
            // 
            // lblgenero
            // 
            this.lblgenero.AutoSize = true;
            this.lblgenero.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgenero.Location = new System.Drawing.Point(14, 188);
            this.lblgenero.Name = "lblgenero";
            this.lblgenero.Size = new System.Drawing.Size(54, 15);
            this.lblgenero.TabIndex = 6;
            this.lblgenero.Text = "Género";
            // 
            // txtnumeroidentificacion
            // 
            this.txtnumeroidentificacion.Location = new System.Drawing.Point(170, 144);
            this.txtnumeroidentificacion.Name = "txtnumeroidentificacion";
            this.txtnumeroidentificacion.Size = new System.Drawing.Size(100, 20);
            this.txtnumeroidentificacion.TabIndex = 5;
            // 
            // lblnumeroidentificacion
            // 
            this.lblnumeroidentificacion.AutoSize = true;
            this.lblnumeroidentificacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnumeroidentificacion.Location = new System.Drawing.Point(14, 144);
            this.lblnumeroidentificacion.Name = "lblnumeroidentificacion";
            this.lblnumeroidentificacion.Size = new System.Drawing.Size(140, 15);
            this.lblnumeroidentificacion.TabIndex = 4;
            this.lblnumeroidentificacion.Text = "Numero Idenficación";
            // 
            // lbltipoidentificacion
            // 
            this.lbltipoidentificacion.AutoSize = true;
            this.lbltipoidentificacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltipoidentificacion.Location = new System.Drawing.Point(11, 84);
            this.lbltipoidentificacion.Name = "lbltipoidentificacion";
            this.lbltipoidentificacion.Size = new System.Drawing.Size(145, 15);
            this.lbltipoidentificacion.TabIndex = 2;
            this.lbltipoidentificacion.Text = "Tipo de identificación";
            // 
            // txtnombrescompletos
            // 
            this.txtnombrescompletos.Location = new System.Drawing.Point(152, 43);
            this.txtnombrescompletos.Name = "txtnombrescompletos";
            this.txtnombrescompletos.Size = new System.Drawing.Size(100, 20);
            this.txtnombrescompletos.TabIndex = 1;
            // 
            // lblnombrescompletos
            // 
            this.lblnombrescompletos.AutoSize = true;
            this.lblnombrescompletos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnombrescompletos.Location = new System.Drawing.Point(11, 40);
            this.lblnombrescompletos.Name = "lblnombrescompletos";
            this.lblnombrescompletos.Size = new System.Drawing.Size(135, 15);
            this.lblnombrescompletos.TabIndex = 0;
            this.lblnombrescompletos.Text = "Nombres completos";
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 453);
            this.Controls.Add(this.gpbdatosbasicos);
            this.Name = "Form8";
            this.Text = "datos basicos paciente";
            ((System.ComponentModel.ISupportInitialize)(this.errorMensaje)).EndInit();
            this.gpbdatosbasicos.ResumeLayout(false);
            this.gpbdatosbasicos.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gpbdatosbasicos;
        private System.Windows.Forms.Button bttguardar;
        private System.Windows.Forms.Button bttregresar;
        private System.Windows.Forms.DateTimePicker dtpfechadenacimiento;
        private System.Windows.Forms.ComboBox cbxtipodeidentificacion;
        private System.Windows.Forms.ComboBox cbxgenero;
        private System.Windows.Forms.ComboBox cbxestadocivil;
        private System.Windows.Forms.ComboBox cbxnivelescolaridad;
        private System.Windows.Forms.ComboBox cbxregimen;
        private System.Windows.Forms.TextBox txtdireccion;
        private System.Windows.Forms.Label lbldireccion;
        private System.Windows.Forms.TextBox txteps;
        private System.Windows.Forms.Label lbleps;
        private System.Windows.Forms.TextBox txtedad;
        private System.Windows.Forms.Label lbledad;
        private System.Windows.Forms.Label lblfechanacimiento;
        private System.Windows.Forms.TextBox txtantecedentes;
        private System.Windows.Forms.Label lblantecedentes;
        private System.Windows.Forms.TextBox txttratamiento;
        private System.Windows.Forms.Label lbltratamiento;
        private System.Windows.Forms.TextBox txtcontactoemergencia;
        private System.Windows.Forms.Label lblcontactoemergencia;
        private System.Windows.Forms.Label lblregimen;
        private System.Windows.Forms.TextBox txtcorreoelectronico;
        private System.Windows.Forms.Label lblcorreoelectronico;
        private System.Windows.Forms.Label lblnivelescolaridad;
        private System.Windows.Forms.TextBox txtocupacion;
        private System.Windows.Forms.Label lblocupacion;
        private System.Windows.Forms.TextBox txttelefono;
        private System.Windows.Forms.Label lbltelefono;
        private System.Windows.Forms.TextBox txtbarrio;
        private System.Windows.Forms.Label lblbarrio;
        private System.Windows.Forms.Label lblestadocivil;
        private System.Windows.Forms.Label lblgenero;
        private System.Windows.Forms.TextBox txtnumeroidentificacion;
        private System.Windows.Forms.Label lblnumeroidentificacion;
        private System.Windows.Forms.Label lbltipoidentificacion;
        private System.Windows.Forms.TextBox txtnombrescompletos;
        private System.Windows.Forms.Label lblnombrescompletos;
        private System.Windows.Forms.ErrorProvider errorMensaje;
    }
}